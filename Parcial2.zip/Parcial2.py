class SubmenuPersonas:
    def __init__(self):
        
        self.personas = []

    def crear_persona(self):
        
        nombre = input("Ingrese el nombre de la persona: ")
        edad = input("Ingrese la edad de la persona: ")
        self.personas.append({"nombre": nombre, "edad": edad})
        print("Persona creada exitosamente.")

    def listar_personas(self):
        
        if self.personas:
            print("Listado de personas:")
            for idx, persona in enumerate(self.personas, 1):
                print(f"{idx}. Nombre: {persona['nombre']}, Edad: {persona['edad']}")
        else:
            print("No hay personas registradas.")

    def eliminar_persona(self):
        
        if self.personas:
            self.listar_personas()
            idx = int(input("Ingrese el número de la persona que desea eliminar: "))
            if 1 <= idx <= len(self.personas):
                del self.personas[idx - 1]
                print("Persona eliminada correctamente.")
            else:
                print("Número de persona inválido.")
        else:
            print("No hay personas registradas.")


class SubmenuUniversidades:
    
    def __init__(self):
        
        self.universidades = []

    def crear_universidad(self):
        
        nombre = input("Ingrese el nombre de la universidad: ")
        ubicacion = input("Ingrese la ubicación de la universidad: ")
        self.universidades.append({"nombre": nombre, "ubicacion": ubicacion})
        print("Universidad creada exitosamente.")

    def listar_universidades(self):
        
        if self.universidades:
            print("Listado de universidades:")
            for idx, universidad in enumerate(self.universidades, 1):
                print(f"{idx}. Nombre: {universidad['nombre']}, Ubicación: {universidad['ubicacion']}")
        else:
            print("No hay universidades registradas.")

    def eliminar_universidad(self):
        
        if self.universidades:
            self.listar_universidades()
            idx = int(input("Ingrese el número de la universidad que desea eliminar: "))
            if 1 <= idx <= len(self.universidades):
                del self.universidades[idx - 1]
                print("Universidad eliminada correctamente.")
            else:
                print("Número de universidad inválido.")
        else:
            print("No hay universidades registradas.")


class SubmenuNotas:
    
    def __init__(self):
        self.notas = []

    def agregar_nota(self):
        
        materia = input("Ingrese la materia: ")
        nota = float(input("Ingrese la nota: "))
        self.notas.append({"materia": materia, "nota": nota})
        print("Nota agregada correctamente.")

    def listar_notas(self):
        
        if self.notas:
            print("Listado de notas:")
            for nota in self.notas:
                print(f"Materia: {nota['materia']}, Nota: {nota['nota']}")
        else:
            print("No hay notas registradas.")

class SubmenuAsignaturas:
    
    def __init__(self):
        self.asignaturas = []

    def agregar_asignatura(self):
        
        nombre = input("Ingrese el nombre de la asignatura: ")
        codigo = input("Ingrese el código de la asignatura: ")
        self.asignaturas.append({"nombre": nombre, "codigo": codigo})
        print("Asignatura agregada correctamente.")

    def listar_asignaturas(self):
        
        if self.asignaturas:
            print("Listado de asignaturas:")
            for asignatura in self.asignaturas:
                print(f"Nombre: {asignatura['nombre']}, Código: {asignatura['codigo']}")
        else:
            print("No hay asignaturas registradas.")


class MenuPrincipal:
    
    def __init__(self):
        
        self.submenu_personas = SubmenuPersonas()
        self.submenu_universidades = SubmenuUniversidades()
        self.submenu_notas = SubmenuNotas()
        self.submenu_asignaturas = SubmenuAsignaturas()

    def mostrar_menu_principal(self):
        
        while True:
            
            print("\nMenu principal")
            print("1. Personas")
            print("2. Universidades")
            print("3. Notas")
            print("4. Asignaturas")
            print("5. Salir")

            opcion = input("Seleccione una opción: ")

            if opcion == "1":
                self.mostrar_submenu_personas()
            elif opcion == "2":
                self.mostrar_submenu_universidades()
            elif opcion == "3":
                self.mostrar_submenu_notas()
            elif opcion == "4":
                self.mostrar_submenu_asignaturas()
            elif opcion == "5":
                print("Ingenierette")
                break
            else:
                print("Opción no válida.")

    def mostrar_submenu_personas(self):
        
        while True:
            
            print("\nSubmenu personas")
            print("1. Crear personas")
            print("2. Listar personas")
            print("3. Eliminar personas")
            print("4. Atras")

            opcion = input("Seleccione una opción: ")

            if opcion == "1":
                self.submenu_personas.crear_persona()
            elif opcion == "2":
                self.submenu_personas.listar_personas()
            elif opcion == "3":
                self.submenu_personas.eliminar_persona()
            elif opcion == "4":
                break
            else:
                print("Opción no válida.")

    def mostrar_submenu_universidades(self):
        
        while True:
            
            print("\nSubmenu Universidades")
            print("1. Crear universidad")
            print("2. Listar Universidades")
            print("3. Eliminar Universidades")
            print("4. Atras")

            opcion = input("Seleccione una opción: ")

            if opcion == "1":
                self.submenu_universidades.crear_universidad()
            elif opcion == "2":
                self.submenu_universidades.listar_universidades()
            elif opcion == "3":
                self.submenu_universidades.eliminar_universidad()
            elif opcion == "4":
                break
            else:
                print("Opción no válida.")

    def mostrar_submenu_notas(self):
        
        while True:
            
            print("\nSubmenu Notas")
            print("1. Agregar Notas")
            print("2. Listar Notas")
            print("3. Atras")

            opcion = input("Seleccione una opción: ")

            if opcion == "1":
                self.submenu_notas.agregar_nota()
            elif opcion == "2":
                self.submenu_notas.listar_notas()
            elif opcion == "3":
                break
            else:
                print("Opción no válida.")

    def mostrar_submenu_asignaturas(self):
        
        while True:
            
            print("\nSubmenu Asignaturas")
            print("1. Agregar Asignaturas")
            print("2. Listar asignaturas")
            print("3. Atras")

            opcion = input("Seleccione una opción: ")

            if opcion == "1":
                self.submenu_asignaturas.agregar_asignatura()
            elif opcion == "2":
                self.submenu_asignaturas.listar_asignaturas()
            elif opcion == "3":
                break
            else:
                print("Opción no válida.")


if __name__ == "__main__":
    menu = MenuPrincipal()
    menu.mostrar_menu_principal()
