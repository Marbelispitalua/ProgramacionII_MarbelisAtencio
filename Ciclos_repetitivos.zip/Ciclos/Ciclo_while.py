elegir = 0
while elegir <= 5:


    print("\n1)persona")
    print("2)vehiculo")
    print("3)universidad")
    print("4)notas")
    print("5)salir")
    
    
    
    elegir = int(input("selecione una opcion del menu: "))
    
    if elegir == 1:
        print("has selecionado persona")
    
    if elegir == 2:
        print("has selecionado vehiculo")
    
    if elegir == 3:
        print("has selecionado universidad")
    
    if elegir == 4:
        print("has selecionado notas")
        
    if elegir == 5:
        print("has salido :) ")
        break
